$('.carousel').slick({
    dots: true,
    autoplay: true,
    autoplaySpeed: 5000,
    fade: true,
    infinite: true,
});

$('.show').modaal();

$('.submit').click(() => {
    alert('イタリアンのレシピをシェアしました♪');
    $('.show').modaal('close');
})
$('.submit_1').click(() => {
    alert('フレンチのレシピをシェアしました♪');
    $('.show').modaal('close');
})
$('.submit_2').click(() => {
    alert('ダイエットのレシピをシェアしました♪');
    $('.show').modaal('close');
})
$('.submit_3').click(() => {
    alert('エスニックのレシピをシェアしました♪');
    $('.show').modaal('close');
})